import { api } from "@/shared/lib/axios/axios.instance";

//Get All
export const getNotifications = (params: {
  pageNumber?: number;
  pageSize?: number;
  onlyUnread?: boolean;
}) => {
  return api.get("/api/admin/notifications/list", {
    params,
  });
};

//Get count
export const getUnreadNotificationsCount = () => {
  return api.get("/api/admin/notifications/unread-count");
};

//Mark Read
export const markNotificationAsRead = (id: number) => {
  return api.post(`/api/admin/notifications/mark-read/${id}`);
};

//Mark All Read
export const markAllNotificationsAsRead = (token: string) => {
  return api.post(
    "/api/admin/notifications/mark-all-read",
    {},
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
};

//Delete All
export const deleteAllNotifications = (token: string) => {
  return api.delete("/api/admin/notifications/delete-all", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};